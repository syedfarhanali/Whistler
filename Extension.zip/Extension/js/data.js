var data = {};
$(document).ready(function(){
	var whistles = new Array();
	var whistle1= {title:'title1',
			image:'images/whistle-orange-logo.jpg',
			description:'We will be having all hands meeting today at 5 pm ,please be there.',
			upvote:12,
			downvote:1};
	whistles.push(whistle1);
	
	var whistle2= {title:'title2',
			image:'images/whistle-orange-logo.jpg',
			description:'This is an amazing java article please read it, also share your views if you like it, Thanks!!',
			upvote:120,
			downvote:0};
	whistles.push(whistle2);
	
	
	
	data.whistles=whistles;
})
